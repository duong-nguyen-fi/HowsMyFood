package com.beuwolf.howsmyfood

import android.support.v7.widget.CardView
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import kotlinx.android.synthetic.main.item.view.*
import java.util.*

/**
 * Created by Beuwolf on 18-Nov-17.
 */
 open class RVAdapter : RecyclerView.Adapter<RVAdapter.FoodViewHolder> {



    open  class FoodViewHolder : RecyclerView.ViewHolder {

        lateinit var cv : CardView
        lateinit var foodName : TextView
        lateinit var foodDate : TextView
        lateinit var foodPhoto : ImageView

         constructor(itemView: View) : super(itemView)
         {
             Log.i("myInfo","FoodViewHolder created")
             cv = itemView.cv
             foodName = itemView.food_name
             foodDate = itemView.food_date
             foodPhoto = itemView.food_photo
         }


    }

    lateinit var foods : List<Food>

    constructor(foods: List<Food>)
    {
        this.foods = foods
        Log.i("myInfo","Adapter Constructor loaded")
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView?) {
        Log.i("myInfo","onAttachRV created")
        super.onAttachedToRecyclerView(recyclerView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
            Log.i("myInfo","ViewHolder created")
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item, parent, false)
            val fvh = FoodViewHolder(v)
            return fvh


    }

    override fun onBindViewHolder(holder: FoodViewHolder?, position: Int) {
        if (holder != null) {
            Log.i("myInfo","FoodViewHolder is not null")
            holder.foodName.setText(foods.get(position).name)
            holder.foodDate.setText(foods.get(position).date)
            holder.foodPhoto.setImageURI(foods.get(position).photoURI)

            holder.itemView.setOnClickListener(View.OnClickListener{view: View -> Log.i("Click","item: " + position)})

        }
        else{
            Log.i("myInfo","ViewHolder is null")
        }
    }

    override fun getItemCount(): Int {
        return (foods.size)
    }
}