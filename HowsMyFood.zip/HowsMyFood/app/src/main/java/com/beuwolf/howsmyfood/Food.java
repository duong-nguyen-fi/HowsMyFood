package com.beuwolf.howsmyfood;

/**
 * Created by Beuwolf on 18-Nov-17.
 */

import android.net.Uri;

/**
 * Created by Beuwolf on 07-Oct-17.
 */

public class Food {
    public String getName() {
        return name;
    }

    String name;

    public String getDate() {
        return date;
    }

    public Uri getPhotoURI() {
        return photoURI;
    }

    String date;
    Uri photoURI;

    Food(String name, String date, Uri photoURI) {
        this.name = name;
        this.date = date;
        this.photoURI = photoURI;
    }


}