package com.beuwolf.howsmyfood

import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    //lateinit var rv : RecyclerView
    lateinit var adapter : RVAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rv.setHasFixedSize(true)
        var llm : LinearLayoutManager = LinearLayoutManager(this)
        rv.layoutManager = llm
        initializeData()
        initializeAdapter()
    }

    open lateinit var foods : List<Food>

    fun initializeData()
    {
        foods = ArrayList<Food>()
        val burgerStr = "android.resource://com.beuwolf.howsmyfood/drawable/burger"
        val pizzaStr = "android.resource://com.beuwolf.howsmyfood/drawable/pizza"
        val kebabStr = "android.resource://com.beuwolf.howsmyfood/drawable/kebab"

        val burgerURI = Uri.parse(burgerStr)
        val pizzaURI = Uri.parse(pizzaStr)
        val kebabURI = Uri.parse(kebabStr)

        Log.i("URI", kebabURI.toString())
        Log.i("URI, Str", kebabStr)

        foods += Food("Burger", "2017-11-13", burgerURI)

        foods += Food("Pizza", "2017-11-14", pizzaURI)
        foods += Food("Kebab", "2017-11-15", kebabURI)
        Log.i("myInfo","Food creation," + foods.size)
    }


    fun initializeAdapter()
    {
        adapter = RVAdapter(foods)
        Log.i("myInfo","RVAPdapter created")
        rv.adapter = adapter
    }
}
